import React from 'react'

export default function Carousal() {
    return (
        <div>
            
        </div>
    )
}
